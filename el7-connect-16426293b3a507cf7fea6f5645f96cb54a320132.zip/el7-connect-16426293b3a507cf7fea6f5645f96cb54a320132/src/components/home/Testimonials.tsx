import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Mitchell",
    role: "CEO, TechVentures",
    content: "EL7 Agency delivered beyond expectations. The quality of freelancers here is unmatched. Our website conversion rate increased by 150% after the redesign.",
    rating: 5,
    image: "SM",
  },
  {
    name: "David Chen",
    role: "Founder, AI Solutions Inc",
    content: "The AI automation expert we hired saved us 40 hours per week. The vetting process clearly works — we got a true expert on our first try.",
    rating: 5,
    image: "DC",
  },
  {
    name: "Maria Rodriguez",
    role: "Marketing Director, GrowthCo",
    content: "Finally, a platform where quality comes first. The 500-freelancer limit might seem restrictive, but it's exactly what ensures premium service.",
    rating: 5,
    image: "MR",
  },
];

export const Testimonials = () => {
  return (
    <section className="relative section-padding bg-gradient-dark">
      {/* Background */}
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-primary/5 rounded-full blur-[150px] -translate-y-1/2" />

      <div className="relative container-custom">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-primary font-medium text-sm uppercase tracking-wider mb-4">Testimonials</p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            See what our clients say about working with EL7 Agency freelancers
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.name}
              className="glass-card p-8 relative group hover:border-primary/30 transition-all duration-300"
            >
              {/* Quote Icon */}
              <Quote className="w-10 h-10 text-primary/20 absolute top-6 right-6" />

              {/* Rating */}
              <div className="flex gap-1 mb-6">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>

              {/* Content */}
              <p className="text-muted-foreground leading-relaxed mb-8">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-gold flex items-center justify-center font-semibold text-primary-foreground">
                  {testimonial.image}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
