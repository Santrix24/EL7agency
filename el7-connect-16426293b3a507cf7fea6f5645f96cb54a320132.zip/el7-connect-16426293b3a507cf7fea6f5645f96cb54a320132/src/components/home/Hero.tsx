import { Link } from "react-router-dom";
import { ArrowRight, Users, Shield, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-radial from-surface-elevated via-background to-background" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px] animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-[100px] animate-float" style={{ animationDelay: '-3s' }} />
      
      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:64px_64px]" />

      <div className="relative container-custom section-padding text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-8 animate-fade-up">
          <Shield className="w-4 h-4" />
          <span>Only 500 Verified Freelancers Accepted</span>
        </div>

        {/* Main Heading */}
        <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 max-w-5xl mx-auto leading-tight animate-fade-up" style={{ animationDelay: '0.1s' }}>
          Premium Digital Services by{" "}
          <span className="gradient-text text-shadow-glow">Elite Freelancers</span>
        </h1>

        {/* Subheading */}
        <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 animate-fade-up" style={{ animationDelay: '0.2s' }}>
          EL7 Agency connects you with the top 1% of verified freelancers for web development, AI automation, branding, and more. Quality guaranteed.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-fade-up" style={{ animationDelay: '0.3s' }}>
          <Link to="/services">
            <Button variant="hero" size="xl" className="group">
              Explore Services
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
          <Link to="/freelancer-login">
            <Button variant="hero-outline" size="xl">
              Apply as Freelancer
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto animate-fade-up" style={{ animationDelay: '0.4s' }}>
          <div className="glass-card px-6 py-5">
            <div className="flex items-center justify-center gap-3">
              <Users className="w-5 h-5 text-primary" />
              <div className="text-left">
                <p className="text-2xl font-bold text-foreground">500</p>
                <p className="text-sm text-muted-foreground">Max Freelancers</p>
              </div>
            </div>
          </div>
          <div className="glass-card px-6 py-5">
            <div className="flex items-center justify-center gap-3">
              <Shield className="w-5 h-5 text-primary" />
              <div className="text-left">
                <p className="text-2xl font-bold text-foreground">100%</p>
                <p className="text-sm text-muted-foreground">Verified Talent</p>
              </div>
            </div>
          </div>
          <div className="glass-card px-6 py-5">
            <div className="flex items-center justify-center gap-3">
              <Zap className="w-5 h-5 text-primary" />
              <div className="text-left">
                <p className="text-2xl font-bold text-foreground">24/7</p>
                <p className="text-sm text-muted-foreground">Support Available</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
