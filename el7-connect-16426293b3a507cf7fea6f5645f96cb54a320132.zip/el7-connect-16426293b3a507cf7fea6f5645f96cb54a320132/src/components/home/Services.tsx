import { Link } from "react-router-dom";
import { Globe, Bot, FileText, TrendingUp, Palette, MessageSquare, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Globe,
    title: "Website Design & Development",
    description: "Custom websites built with cutting-edge technologies. From landing pages to complex web applications.",
    price: "From $500",
  },
  {
    icon: Bot,
    title: "AI Automation",
    description: "Streamline your workflows with intelligent automation. Save time and reduce errors with AI-powered solutions.",
    price: "From $800",
  },
  {
    icon: FileText,
    title: "Website Copywriting",
    description: "Compelling copy that converts visitors into customers. SEO-optimized content that ranks and resonates.",
    price: "From $300",
  },
  {
    icon: TrendingUp,
    title: "Sales Funnels",
    description: "High-converting sales funnels designed to maximize your ROI. From lead capture to checkout optimization.",
    price: "From $600",
  },
  {
    icon: Palette,
    title: "Branding & UI/UX",
    description: "Build a memorable brand identity. User-centric design that delights and drives engagement.",
    price: "From $700",
  },
  {
    icon: MessageSquare,
    title: "Chatbot Automation",
    description: "24/7 customer engagement with intelligent chatbots. Reduce support costs while improving satisfaction.",
    price: "From $400",
  },
];

export const Services = () => {
  return (
    <section className="relative section-padding bg-gradient-dark">
      {/* Background accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-primary/5 rounded-full blur-[150px]" />
      
      <div className="relative container-custom">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-primary font-medium text-sm uppercase tracking-wider mb-4">Our Services</p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Premium Digital Services
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Every service delivered by vetted professionals with proven track records
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="glass-card-hover p-8 group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <service.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                {service.description}
              </p>
              <p className="text-primary font-semibold">{service.price}</p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/services">
            <Button variant="premium" size="lg" className="group">
              View All Services
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};
