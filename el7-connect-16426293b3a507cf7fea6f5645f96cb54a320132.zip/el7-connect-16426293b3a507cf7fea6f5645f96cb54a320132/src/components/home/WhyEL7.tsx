import { Shield, Users, Award, Lock, Clock, Headphones } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Quality Controlled",
    description: "Every freelancer goes through rigorous vetting. Only the top 1% make the cut.",
  },
  {
    icon: Users,
    title: "Limited to 500",
    description: "We cap freelancers at 500 to maintain exceptional quality and dedicated support.",
  },
  {
    icon: Award,
    title: "Proven Track Records",
    description: "All freelancers have verified portfolios and client testimonials.",
  },
  {
    icon: Lock,
    title: "Secure Payments",
    description: "Your payments are protected with escrow until project completion.",
  },
  {
    icon: Clock,
    title: "On-Time Delivery",
    description: "98% of projects delivered on or before deadline. Time is money.",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "Dedicated support team ready to help you anytime, anywhere.",
  },
];

export const WhyEL7 = () => {
  return (
    <section className="relative section-padding overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-card/30" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[150px]" />

      <div className="relative container-custom">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <p className="text-primary font-medium text-sm uppercase tracking-wider mb-4">Why Choose Us</p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Not Just Another <span className="gradient-text">Freelance Platform</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              EL7 Agency is built on exclusivity and trust. We don't just connect you with freelancers — we connect you with the best in the industry. Our strict 500-freelancer limit ensures every professional on our platform is exceptional.
            </p>
            
            <div className="glass-card p-6 inline-flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">10</span>
              </div>
              <div>
                <p className="font-semibold text-foreground">10-20% Platform Commission</p>
                <p className="text-sm text-muted-foreground">Transparent pricing, no hidden fees</p>
              </div>
            </div>
          </div>

          {/* Right Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="glass-card p-6 hover:border-primary/30 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
