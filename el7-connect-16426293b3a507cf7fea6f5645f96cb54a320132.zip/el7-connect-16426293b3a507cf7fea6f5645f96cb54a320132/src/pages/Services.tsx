import { Link } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Globe, Bot, FileText, TrendingUp, Palette, MessageSquare, ArrowRight, Check } from "lucide-react";

const services = [
  {
    icon: Globe,
    title: "Website Design & Development",
    description: "Custom websites built with cutting-edge technologies. From landing pages to complex web applications.",
    price: "From $500",
    features: ["Responsive Design", "SEO Optimized", "Fast Loading", "CMS Integration", "E-commerce Ready"],
  },
  {
    icon: Bot,
    title: "AI Automation",
    description: "Streamline your workflows with intelligent automation. Save time and reduce errors with AI-powered solutions.",
    price: "From $800",
    features: ["Workflow Automation", "Data Processing", "AI Integration", "Custom Scripts", "API Development"],
  },
  {
    icon: FileText,
    title: "Website Copywriting",
    description: "Compelling copy that converts visitors into customers. SEO-optimized content that ranks and resonates.",
    price: "From $300",
    features: ["SEO Content", "Landing Pages", "Blog Articles", "Product Descriptions", "Email Sequences"],
  },
  {
    icon: TrendingUp,
    title: "Sales Funnels",
    description: "High-converting sales funnels designed to maximize your ROI. From lead capture to checkout optimization.",
    price: "From $600",
    features: ["Lead Magnets", "Email Sequences", "Landing Pages", "A/B Testing", "Analytics Setup"],
  },
  {
    icon: Palette,
    title: "Branding & UI/UX",
    description: "Build a memorable brand identity. User-centric design that delights and drives engagement.",
    price: "From $700",
    features: ["Logo Design", "Brand Guidelines", "UI Design", "UX Research", "Prototyping"],
  },
  {
    icon: MessageSquare,
    title: "Chatbot Automation",
    description: "24/7 customer engagement with intelligent chatbots. Reduce support costs while improving satisfaction.",
    price: "From $400",
    features: ["AI Chatbots", "Live Chat Setup", "FAQ Automation", "Lead Qualification", "Multi-platform"],
  },
];

const ServicesPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        {/* Hero Section */}
        <section className="section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-radial from-surface-elevated via-background to-background" />
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
          
          <div className="relative container-custom text-center">
            <p className="text-primary font-medium text-sm uppercase tracking-wider mb-4">Our Services</p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              Premium <span className="gradient-text">Digital Services</span>
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Every service delivered by vetted professionals with proven track records. Quality guaranteed or your money back.
            </p>
          </div>
        </section>

        {/* Services Grid */}
        <section className="section-padding bg-gradient-dark">
          <div className="container-custom">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service) => (
                <div
                  key={service.title}
                  className="glass-card-hover p-8 flex flex-col"
                >
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                    <service.icon className="w-7 h-7 text-primary" />
                  </div>
                  
                  <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                    {service.title}
                  </h3>
                  
                  <p className="text-muted-foreground text-sm mb-6 leading-relaxed flex-grow">
                    {service.description}
                  </p>

                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Check className="w-4 h-4 text-primary flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <p className="text-primary font-bold text-lg">{service.price}</p>
                    <Link to="/freelancers">
                      <Button variant="ghost" size="sm" className="group">
                        Get Started
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="section-padding">
          <div className="container-custom text-center">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-6">
              Need a Custom Solution?
            </h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
              Contact us for custom projects tailored to your specific needs.
            </p>
            <Link to="/contact">
              <Button variant="hero" size="xl" className="group">
                Contact Us
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default ServicesPage;
