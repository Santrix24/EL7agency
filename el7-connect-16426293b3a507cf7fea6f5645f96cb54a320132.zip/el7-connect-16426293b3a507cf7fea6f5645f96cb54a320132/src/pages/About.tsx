import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Shield, Target, Heart, Zap, Users, Award } from "lucide-react";

const values = [
  {
    icon: Shield,
    title: "Quality First",
    description: "We never compromise on quality. Every freelancer is rigorously vetted to ensure exceptional standards.",
  },
  {
    icon: Target,
    title: "Results Driven",
    description: "We focus on outcomes, not just outputs. Your success is our measure of success.",
  },
  {
    icon: Heart,
    title: "Client Centric",
    description: "Your needs come first. We're committed to delivering solutions that exceed expectations.",
  },
  {
    icon: Zap,
    title: "Innovation",
    description: "We embrace cutting-edge technologies and methodologies to stay ahead of the curve.",
  },
];

const stats = [
  { number: "500", label: "Max Freelancers", description: "Exclusive network limit" },
  { number: "98%", label: "Satisfaction Rate", description: "Client happiness score" },
  { number: "10-20%", label: "Commission", description: "Transparent pricing" },
  { number: "24/7", label: "Support", description: "Always here for you" },
];

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        {/* Hero */}
        <section className="section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-radial from-surface-elevated via-background to-background" />
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
          
          <div className="relative container-custom">
            <div className="max-w-3xl">
              <p className="text-primary font-medium text-sm uppercase tracking-wider mb-4">About EL7 Agency</p>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6">
                Building the Future of <span className="gradient-text">Freelancing</span>
              </h1>
              <p className="text-muted-foreground text-lg leading-relaxed">
                EL7 Agency was founded with a simple yet powerful vision: to create a platform where quality triumphs over quantity. In a world flooded with freelance marketplaces, we chose to be different. We chose to be exclusive.
              </p>
            </div>
          </div>
        </section>

        {/* Mission */}
        <section className="section-padding bg-gradient-dark">
          <div className="container-custom">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-6">
                  Our Mission
                </h2>
                <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                  To connect ambitious businesses with exceptional talent. We believe that by limiting our freelancer network to just 500 professionals, we can maintain the highest standards of quality, reliability, and expertise.
                </p>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  Every freelancer on our platform has been hand-selected based on their skills, experience, and track record. This isn't just a marketplace — it's a curated community of the best in the industry.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat) => (
                  <div key={stat.label} className="glass-card p-6 text-center">
                    <p className="text-3xl font-bold gradient-text mb-1">{stat.number}</p>
                    <p className="text-foreground font-medium mb-1">{stat.label}</p>
                    <p className="text-sm text-muted-foreground">{stat.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="section-padding">
          <div className="container-custom">
            <div className="text-center mb-16">
              <p className="text-primary font-medium text-sm uppercase tracking-wider mb-4">Our Values</p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-4">
                What Drives Us
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Our core values shape everything we do at EL7 Agency
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value) => (
                <div key={value.title} className="glass-card-hover p-8 text-center">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <value.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-foreground mb-3">
                    {value.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why 500 */}
        <section className="section-padding bg-card/30">
          <div className="container-custom">
            <div className="max-w-3xl mx-auto text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-gold flex items-center justify-center mx-auto mb-8 shadow-gold">
                <Users className="w-10 h-10 text-primary-foreground" />
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-6">
                Why Only 500 Freelancers?
              </h2>
              <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                Quality over quantity isn't just a slogan — it's our business model. By limiting our network to 500 exceptional freelancers, we ensure:
              </p>
              <div className="grid sm:grid-cols-3 gap-6 text-left">
                <div className="glass-card p-6">
                  <Award className="w-6 h-6 text-primary mb-3" />
                  <h4 className="font-semibold text-foreground mb-2">Rigorous Vetting</h4>
                  <p className="text-sm text-muted-foreground">Each freelancer passes a comprehensive evaluation process</p>
                </div>
                <div className="glass-card p-6">
                  <Shield className="w-6 h-6 text-primary mb-3" />
                  <h4 className="font-semibold text-foreground mb-2">Consistent Quality</h4>
                  <p className="text-sm text-muted-foreground">Maintain high standards across all projects</p>
                </div>
                <div className="glass-card p-6">
                  <Heart className="w-6 h-6 text-primary mb-3" />
                  <h4 className="font-semibold text-foreground mb-2">Personal Support</h4>
                  <p className="text-sm text-muted-foreground">Dedicated attention for every client and freelancer</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default AboutPage;
