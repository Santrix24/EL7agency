import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

const PrivacyPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <section className="section-padding">
          <div className="container-custom max-w-4xl">
            <h1 className="font-display text-4xl font-bold text-foreground mb-8">
              Privacy Policy
            </h1>
            
            <div className="prose prose-invert max-w-none space-y-8">
              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">1. Information We Collect</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  We collect information you provide directly to us, including:
                </p>
                <ul className="text-muted-foreground space-y-2">
                  <li>• Name and contact information</li>
                  <li>• Account credentials</li>
                  <li>• Payment information</li>
                  <li>• Profile information (for freelancers)</li>
                  <li>• Communication data</li>
                </ul>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">2. How We Use Your Information</h2>
                <ul className="text-muted-foreground space-y-2">
                  <li>• To provide and maintain our services</li>
                  <li>• To process transactions</li>
                  <li>• To communicate with you</li>
                  <li>• To improve our platform</li>
                  <li>• To ensure security and prevent fraud</li>
                </ul>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">3. Information Sharing</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We do not sell your personal information. We may share information with service providers who assist in our operations, when required by law, or to protect our rights and safety.
                </p>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">4. Data Security</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.
                </p>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">5. Your Rights</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  You have the right to:
                </p>
                <ul className="text-muted-foreground space-y-2">
                  <li>• Access your personal data</li>
                  <li>• Correct inaccurate data</li>
                  <li>• Request deletion of your data</li>
                  <li>• Object to processing</li>
                  <li>• Data portability</li>
                </ul>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">6. Contact Us</h2>
                <p className="text-muted-foreground leading-relaxed">
                  For privacy-related inquiries, contact us at abielcartier@gmail.com or call +91 7086156649.
                </p>
              </div>

              <p className="text-sm text-muted-foreground">
                Last updated: {new Date().toLocaleDateString()}
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default PrivacyPage;
