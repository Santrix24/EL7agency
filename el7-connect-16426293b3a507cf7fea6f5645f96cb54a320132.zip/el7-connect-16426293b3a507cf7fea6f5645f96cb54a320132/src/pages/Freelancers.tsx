import { Link } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Star, MapPin, ArrowRight, Search, Filter, Users } from "lucide-react";
import { Input } from "@/components/ui/input";

const freelancers = [
  {
    name: "Alex Thompson",
    role: "Full-Stack Developer",
    skills: ["React", "Node.js", "TypeScript"],
    rating: 4.9,
    reviews: 47,
    hourlyRate: "$75/hr",
    location: "San Francisco, USA",
    avatar: "AT",
    available: true,
  },
  {
    name: "Priya Sharma",
    role: "AI/ML Specialist",
    skills: ["Python", "TensorFlow", "NLP"],
    rating: 5.0,
    reviews: 32,
    hourlyRate: "$95/hr",
    location: "Mumbai, India",
    avatar: "PS",
    available: true,
  },
  {
    name: "Marcus Weber",
    role: "UI/UX Designer",
    skills: ["Figma", "Branding", "Motion"],
    rating: 4.8,
    reviews: 58,
    hourlyRate: "$65/hr",
    location: "Berlin, Germany",
    avatar: "MW",
    available: false,
  },
  {
    name: "Sophie Chen",
    role: "Copywriter & Strategist",
    skills: ["SEO", "Content Strategy", "Email"],
    rating: 4.9,
    reviews: 41,
    hourlyRate: "$55/hr",
    location: "London, UK",
    avatar: "SC",
    available: true,
  },
  {
    name: "James Okonkwo",
    role: "Sales Funnel Expert",
    skills: ["ClickFunnels", "Automation", "CRO"],
    rating: 4.7,
    reviews: 29,
    hourlyRate: "$70/hr",
    location: "Lagos, Nigeria",
    avatar: "JO",
    available: true,
  },
  {
    name: "Elena Rodriguez",
    role: "Chatbot Developer",
    skills: ["Dialogflow", "Botpress", "AI"],
    rating: 4.8,
    reviews: 36,
    hourlyRate: "$60/hr",
    location: "Barcelona, Spain",
    avatar: "ER",
    available: true,
  },
];

const FreelancersPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        {/* Hero */}
        <section className="section-padding relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-radial from-surface-elevated via-background to-background" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
          
          <div className="relative container-custom text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
              <Users className="w-4 h-4" />
              <span>487/500 Freelancers Registered</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              Discover <span className="gradient-text">Elite Talent</span>
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              Browse our curated marketplace of verified freelancers. Only the top 1% make it to EL7 Agency.
            </p>

            {/* Search */}
            <div className="max-w-2xl mx-auto flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search by skill or role..."
                  className="pl-12 h-12 bg-card border-border"
                />
              </div>
              <Button variant="glass" size="lg" className="gap-2">
                <Filter className="w-4 h-4" />
                Filters
              </Button>
            </div>
          </div>
        </section>

        {/* Freelancers Grid */}
        <section className="section-padding bg-gradient-dark">
          <div className="container-custom">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {freelancers.map((freelancer) => (
                <div
                  key={freelancer.name}
                  className="glass-card-hover p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-gradient-gold flex items-center justify-center font-semibold text-primary-foreground text-lg">
                        {freelancer.avatar}
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{freelancer.name}</h3>
                        <p className="text-sm text-muted-foreground">{freelancer.role}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      freelancer.available 
                        ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                        : 'bg-muted text-muted-foreground border border-border'
                    }`}>
                      {freelancer.available ? 'Available' : 'Busy'}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {freelancer.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1 bg-secondary rounded-full text-xs text-secondary-foreground"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-primary text-primary" />
                      <span className="text-foreground font-medium">{freelancer.rating}</span>
                      <span>({freelancer.reviews})</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {freelancer.location}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <p className="text-primary font-bold">{freelancer.hourlyRate}</p>
                    <Button variant="ghost" size="sm" className="group" disabled={!freelancer.available}>
                      View Profile
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="section-padding">
          <div className="container-custom text-center">
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground mb-6">
              Want to Join Our Elite Network?
            </h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
              Only 13 spots remaining. Apply now to join the top 1% of freelancers.
            </p>
            <Link to="/freelancer-login">
              <Button variant="hero" size="xl" className="group">
                Apply as Freelancer
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default FreelancersPage;
