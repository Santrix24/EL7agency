import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

const TermsPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <section className="section-padding">
          <div className="container-custom max-w-4xl">
            <h1 className="font-display text-4xl font-bold text-foreground mb-8">
              Terms of Service
            </h1>
            
            <div className="prose prose-invert max-w-none space-y-8">
              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">1. Introduction</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Welcome to EL7 Agency. By accessing or using our platform, you agree to be bound by these Terms of Service. Our platform connects clients with verified freelancers for digital services.
                </p>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">2. Platform Services</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  EL7 Agency provides a marketplace for digital services including but not limited to web development, AI automation, copywriting, sales funnels, branding, and chatbot automation.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  We maintain a maximum of 500 freelancers on our platform to ensure quality and dedicated support for all users.
                </p>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">3. Commission Structure</h2>
                <p className="text-muted-foreground leading-relaxed">
                  EL7 Agency charges a platform commission of 10-20% on every completed order. This commission is automatically deducted from the freelancer's payment before payout.
                </p>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">4. User Responsibilities</h2>
                <ul className="text-muted-foreground space-y-2">
                  <li>• Users must provide accurate information during registration</li>
                  <li>• Freelancers must deliver work as agreed with clients</li>
                  <li>• Clients must pay for services as agreed</li>
                  <li>• All users must comply with applicable laws and regulations</li>
                </ul>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">5. Dispute Resolution</h2>
                <p className="text-muted-foreground leading-relaxed">
                  In case of disputes between clients and freelancers, EL7 Agency will mediate to find a fair resolution. Our decision in dispute matters is final.
                </p>
              </div>

              <div className="glass-card p-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">6. Contact</h2>
                <p className="text-muted-foreground leading-relaxed">
                  For questions about these terms, contact us at abielcartier@gmail.com or call +91 7086156649.
                </p>
              </div>

              <p className="text-sm text-muted-foreground">
                Last updated: {new Date().toLocaleDateString()}
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default TermsPage;
